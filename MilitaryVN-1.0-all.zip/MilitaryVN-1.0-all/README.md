# MilitaryVN
------
Currently the only way to run the game is through Ren'Py:

1. Create a project in Ren'Py

2. Delete everything in the project folder

3. Download the zip file of this project

4. Extract and Place these files in the empty project folder

5. Run Ren'Py and click Launch Project

Alternatively to 3. is to fork the project and pull the project to the empty project folder using git.

When you are finished editing your files and pushed it to your repository, throw up a pull request, and I'll take a look at it and give feedback.

***All of the images currently are temporary.***
